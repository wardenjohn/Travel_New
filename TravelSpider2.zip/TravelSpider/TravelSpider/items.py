# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

from scrapy import  Item,Field


class TravelspiderItem(Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    name=Field() #景点名字
    img_url=Field() #景点图片
    remark=Field() #一句话简介
    area=Field() #景区所在区域
    address=Field() #景区详细地址
    introduce=Field() #详细介绍
    opentime=Field()  #开放时间
    tips=Field()   #注意事项
    transfer=Field()  #交通路线
