# -*- coding: utf-8 -*-
import scrapy
from scrapy import Spider,Request
import requests
import lxml.html
from TravelSpider.items import TravelspiderItem

startPage=1
URL='http://piao.qunar.com/ticket/list.htm?keyword=%E5%8C%97%E4%BA%AC&region=&from=mpl_search_suggest&page={page}'
class TravelSpider(scrapy.Spider):
    name = 'travel'
    allowed_domains = ['www.qunar.com']
    page=startPage
    start_urls = [URL.format(page=page)]
    flag=20
    def parse(self, response):
        res=response.xpath('//div[@class="result_list"]/div')
        cnt=0
        for each in res:
            name = each.xpath('//div[@class="sight_item_about"]/h3/a/text()').extract()
            name=name[cnt]
            url1=each.xpath('//div[@class="sight_item_about"]/h3/a/@href').extract()
            travel_url="http://piao.qunar.com"+url1[cnt]
            # print(travel_url)
            url2=each.xpath('//div[@class="show loading"]/a/img/@data-original').extract()
            img_url=url2[cnt]
            area=each.xpath('//div[@class="sight_item_info"]//span[@class="area"]/a/text()').extract()
            area=area[cnt]
            address=each.xpath('//div[@class="sight_item_info"]/p[@class="address color999"]/span//text()').extract()
            address=address[cnt]
            remark=each.xpath('//div[@class="sight_item_info"]/div[@class="intro color999"]/text()').extract()
            remark=remark[cnt]
            cnt+=1
            # print(name,img_url,area,address,remark)

            #通过URL获取页面具体内容
            html=requests.get(travel_url).content
            selector = lxml.html.document_fromstring(html)
            introduce=selector.xpath('//div[@class="mp-charact-intro"]/div[@class="mp-charact-desc"]/p/text()')
            introduce=''.join(introduce)
            opentime=selector.xpath('//div[@class="mp-charact-time"]//div[@class="mp-charact-desc"]/p/text()')
            opentime=''.join(opentime)
            if opentime=="":
                opentime="暂无"
            tips=selector.xpath('//div[@class="mp-charact-littletips"]//p/text()')
            tips=''.join(tips)
            if tips=="":
                tips="暂无"
            transfer=selector.xpath('//div[@class="mp-traffic-transfer"]//p/text()')
            transfer=''.join(transfer)
            if transfer=="":
                transfer="暂无"

            item=TravelspiderItem()
            item['name']=name
            item['img_url']=img_url
            item['area']=area
            item['address']=address
            item['remark']=remark
            item['introduce']=introduce
            item['opentime']=opentime
            item['tips']=tips
            item['transfer']=transfer
            yield item

            if self.page != self.flag:
                self.page=self.page+1
                yield Request(URL.format(page=self.page),self.parse,dont_filter=True)

